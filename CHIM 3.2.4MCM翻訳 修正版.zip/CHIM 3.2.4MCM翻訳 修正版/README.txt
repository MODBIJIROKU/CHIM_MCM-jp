・Scripts/AIAgentMCMConfigScript.pex の方は、CHIM(AIagent)3.2.4の同名のファイルを上書きして使用して下さい
・AIAgentMCMConfigScript_pex_english_japanese.xmlの方は、xTranslatorを使用して翻訳する用です

翻訳はどちらか一方でOKです。どちらでもお好みの方法で使用して頂ければと思いますので、よろしくお願いいたします

※Scripts/AIAgentMCMConfigScript.pex の方は、3.2.4専用ですので、他のバージョンに当てないようご注意ください

==============================================================

元MOD: CHIM - Pair Any NPC（作者: rang97）
https://www.nexusmods.com/skyrimspecialedition/mods/126330
本ファイルは、MCMメニューの非公式日本語翻訳です
すべてのオリジナルアセットは rang97 氏に帰属します